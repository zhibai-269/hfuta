price=[1:6]'
dates=[today:today+5]'
obj=fints(dates,price)
