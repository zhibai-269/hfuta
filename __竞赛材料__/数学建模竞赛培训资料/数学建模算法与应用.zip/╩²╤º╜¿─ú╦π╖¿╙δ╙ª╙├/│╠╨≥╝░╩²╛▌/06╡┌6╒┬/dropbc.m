function res=dropbc(ya,yb);
res=[ya(1);yb(1)];
