syms x a
b=limit((1+a/x)^x,x,inf)
