function y=Afun1(x);
if x<1
      y=x+1;
else
      y=1+1./x;
end
