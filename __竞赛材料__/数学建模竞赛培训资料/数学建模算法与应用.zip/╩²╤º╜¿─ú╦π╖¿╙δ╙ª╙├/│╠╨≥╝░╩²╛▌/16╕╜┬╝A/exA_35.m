a=imread('data6.bmp');
imshow(a)
imwrite(a,'data7.jpg');
figure, imshow('data7.jpg')
